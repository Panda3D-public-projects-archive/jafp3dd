from pandac.PandaModules import loadPrcFileData
loadPrcFileData("", "window-type none")
#loadPrcFileData("", "clock-mode limited")
#loadPrcFileData("", "client-sleep 0.001")
loadPrcFileData("", "audio-library-name null")



import direct.directbase.DirectStart
#from direct.showbase import ShowBase
#from pandac.PandaModules import *
#from direct.showbase.DirectObject import DirectObject
from pandac.PandaModules import QueuedConnectionManager, QueuedConnectionListener ,QueuedConnectionReader 
from pandac.PandaModules import ConnectionWriter , PointerToConnection ,NetAddress ,NetDatagram
from direct.task import Task 
from direct.distributed.PyDatagram import PyDatagram 
from direct.distributed.PyDatagramIterator import PyDatagramIterator 
import rencode


class Server():
    """
    This is the Server. Clients connect to to it and stay connected as long as they are playing the game.
    It's job is to receive data from the client. and distribute it amongst clients
    """
    def __init__(self):
        self.Clients = []
        self.startServer()

    def __initNetwork(self):  
        self.cManager = QueuedConnectionManager()  
        self.cListener = QueuedConnectionListener(self.cManager, 0)
        self.cReader = QueuedConnectionReader(self.cManager, 0)
        self.cWriter = ConnectionWriter(self.cManager,0)
        
        
    def startServer(self):
        self.__initNetwork()
        self.tcpSocket = self.cManager.openTCPServerRendezvous(9010, 1000) #port, timeout
        self.cListener.addConnection(self.tcpSocket)

        # Start Listener task
        taskMgr.add(self.__listenTask, "serverListenTask")

        # Start Read task
        taskMgr.add(self.__readTask, "serverReadTask" , 40)
        taskMgr.doMethodLater( 2, self.__detectDisconnect, 'findLostPlayers' )
        print "Server STARTED" 
    
    def __listenTask(self, task): #the task that listens for new connections
        """
        Accept new incoming connections from the client
        """
        # Run this task after the dataLoop
        # If there's a new connection Handle it
        if self.cListener.newConnectionAvailable():
            rendezvous = PointerToConnection()
            netAddress = NetAddress()
            newConnection = PointerToConnection()
            if self.cListener.getNewConnection(rendezvous,netAddress,newConnection):
                newConnection = newConnection.p()
                # tell the Reader that there's a new connection to read from
                self.cReader.addConnection(newConnection)
                #Clients[newConnection] = netAddress.getIpString() 
                #might come in handy to detect low intensity distributed brute force attacks. mabe using the NetGeo database
                self.lastConnection = newConnection
                print "CS: Client connected"
                self.__sendData("connected successfully",self.lastConnection)
                self.Clients.append(self.lastConnection) #add the connection to the list of connections
            else:
                print "getNewConnection returned ...nothing.. WTF!?"
        return Task.cont 
    
    def __sendData(self,data,connection):
        #print "CS sending to Client: ",data
        datagram = PyDatagram()
        datagram.addString(rencode.dumps(data,False))
        self.cWriter.send(datagram, connection)
    
    def __readTask(self,task):
        if self.cReader.dataAvailable():
            datagram = NetDatagram()
            if self.cReader.getData(datagram):
                pkg = PyDatagramIterator(datagram)
                try:
                    data = rencode.loads(pkg.getString())
                except:
                    print "GOT CORRUPT DATA FROM CLIENT!!"
                    data=None
                   
                print "CS received from Client: %s" %data
                sender = datagram.getConnection()
                if data != None:
                    for recipent in self.Clients:
                        self.__sendData(data,recipent)
                        
        
        return Task.cont 
    
    def __detectDisconnect(self,task):
        if self.cManager.resetConnectionAvailable() == True:
            connPointer = PointerToConnection()
            self.cManager.getResetConnection(connPointer)
            connection = connPointer.p()
          
            if connection in self.Clients:
                self.Clients.pop(self.Clients.index(connection) )
                print self.Clients
            print "CS: Client disconnected" ,connection
            self.cManager.closeConnection(connection)
        return Task.again

    
if __name__ == "__main__":
    serv = Server()
    run()
