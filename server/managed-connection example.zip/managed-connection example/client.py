from pandac.PandaModules import loadPrcFileData
loadPrcFileData("", "window-type none")
loadPrcFileData("", "client-sleep 0.001")
loadPrcFileData("", "audio-library-name null")

#you might want to remove the direct-start import line.
import direct.directbase.DirectStart

from pandac.PandaModules import QueuedConnectionManager, QueuedConnectionListener ,QueuedConnectionReader 
from pandac.PandaModules import ConnectionWriter, PointerToConnection 
from pandac.PandaModules import NetDatagram
from direct.task import Task 
from direct.distributed.PyDatagram import PyDatagram 
from direct.distributed.PyDatagramIterator import PyDatagramIterator 
import rencode



class NetClass:
    """
    this class handles the basic networking. such as connect,send and receive
    """
    def __init__(self):
        self.Connection = None
        self.newConnection=None
        
    
    def initNetwork(self):
        """
        sets up the basic networking stuff such as connection manager and such
        """
        self.cManager = QueuedConnectionManager()  
        self.cListener = QueuedConnectionListener(self.cManager, 0)
        self.cReader = QueuedConnectionReader(self.cManager, 0)
        self.cWriter = ConnectionWriter(self.cManager,0)
        self.connectToServer("localhost",9010)
        
        
        self.sendData("teststring1") # TESTING the connection, server should echo back
     

    def connectToServer(self,address,port,timeout=6000):   
        self.newConnection = self.cManager.openTCPClientConnection(address,port,timeout)
        if self.newConnection == None:
            print "connecting to Server failed"
            return 1
        self.Connection= self.newConnection
        self.cReader.addConnection(self.Connection)        
        taskMgr.add(self.__readTask, "readDataTask")
        print "connected to the Server"
        return 0
    
    def sendData(self,data):
        """
        sends the given data to the server (if connected).please make sure your data is not totaly f***ed up :)
        """
        if self.Connection != None:
          print data
          datagram = PyDatagram()
          datagram.addString(rencode.dumps(data,False))       
          #print datagram
          self.cWriter.send(datagram, self.Connection)
        else:
          print "DATA NOT SEND. NO CONNECTION OR NOT CORRECTLY LOOGED IN ONTO SERVER"
      
      
    def __readTask(self,task):
        """
        the task which is listening for incomming packages.
        """
        data = None
        if self.cReader.dataAvailable():
          datagram = NetDatagram()
          
          if self.cReader.getData(datagram):
            #print datagram.getConnection()
            #print "datagrammlength:", datagram.getLength()
            pkg = PyDatagramIterator(datagram)
            try:
              data = rencode.loads(pkg.getString())
            except:
              print "got corrupt data from the server.. what the heck.. and who hacked?.."
              data = None
        if data != None:
            print "Client received:",data
            #insert your handler functions here :) \o/  partytime.. DATA!!!!      
            #self.__dataHandler(data)
            
            pass
        
        if self.cManager.resetConnectionAvailable() == True:
            print "reset connection found" #aka as disconnect iirc
            connPointer = PointerToConnection()
            self.cManager.getResetConnection(connPointer)
            connection = connPointer.p()
                  
        return Task.cont
    
    def __dataHandler(self,data):
        ####in case of fresh connection####
        #do something with your data here...
        pass

        
if __name__ == "__main__":
    network = NetClass()
    network.initNetwork()
    run()

